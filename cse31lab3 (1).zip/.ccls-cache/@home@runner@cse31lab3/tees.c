#include <stdio.h>
#include <stdlib.h>

int main() {
  int i;
  int four_ints[4];
  char *c;

  for(i=0; i<4; i++) four_ints[i] =2;

  c = (char*)four_ints;
  for(i=0; i<4; i++) c[i] = 1;

  printf("%x\n", four_ints[2]);
}