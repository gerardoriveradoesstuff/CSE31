#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Declarations of the two functions you will implement
// Feel free to declare any helper functions or global variables
void printPuzzle(char** arr);// given 2d array
void searchPuzzle(char** arr, char* word);// given a 2d array and an array that makes a word
int bSize;

// Main function, DO NOT MODIFY 	
int main(int argc, char **argv) {
  if (argc != 2) { // error message no file given so tells the user to give a file
    fprintf(stderr, "Usage: %s <puzzle file name>\n", argv[0]);
    return 2;
  }
  int i, j;
  FILE *fptr;

  // Open file for reading puzzle
  fptr = fopen(argv[1], "r"); // opens file in read only mode
  if (fptr == NULL) { 
    printf("Cannot Open Puzzle File!\n");
    return 0;
  }

  // Read the size of the puzzle block
  fscanf(fptr, "%d\n", &bSize); //reads first line and gives it to bSize value
    
  // Allocate space for the puzzle block and the word to be searched
  char **block = (char**)malloc(bSize * sizeof(char*));
  char *word = (char*)malloc(20 * sizeof(char));

  // Read puzzle block into 2D arrays
  for(i = 0; i < bSize; i++) {
    *(block + i) = (char*)malloc(bSize * sizeof(char));
    for (j = 0; j < bSize - 1; ++j) {
      fscanf(fptr, "%c ", *(block + i) + j);            
    }
  fscanf(fptr, "%c \n", *(block + i) + j);
  }
  fclose(fptr);

  printf("Enter the word to search: ");
  scanf("%s", word);
    
  // Print out original puzzle grid
  printf("\nPrinting puzzle before search:\n");
  printPuzzle(block);
    
  // Call searchPuzzle to the word in the puzzle
  searchPuzzle(block, word);
    
  return 0;
}

char ignoreCapital(char c) { 
  if (c >= 'A' && c <= 'Z') { // if c is greater than or equal to uppercase A and less than and equal to uppercase Z
    return c + ('a' - 'A'); // C + 32 changes allows other letters to be changed to lower case since the difference in ascii of a - A is 32. 
  }
  return c;
}
//prints the puzzle
void printPuzzle(char** arr) {
	// This function will print out the complete puzzle grid (arr). 
    // It must produce the output in the SAME format as the samples 
    // in the instructions.
    // Your implementation here...
  for (int i = 0; i < bSize; i++) { // traverse columns
    for (int j = 0; j < bSize; j++) { // traverse rows
      printf("%c ", *(*(arr + i) + j));// similar to arr[i][j]
    }
    printf("\n");
  }
}

//does depth first search, checks if out of bounds, to ignore capital, 
// visited is a pointer to a pointer to a pointer char which is dynamically allocated, a pointer to a pointer char array which is dynamically allocated,  
int searchFrom(char*** visited, char** arr, char* word, int row, int col, int currentchar, int* counts) {

  // set the row size
int **directions = (int**) malloc(8 * sizeof(int*));

 // set the column size
for(int i = 0; i < 8; ++i) {
  *(directions + i) = (int*) malloc(2 * sizeof(int));
}

  *(*(directions + 0) + 0) = -1; *(*(directions + 0) + 1) = 0;  // Up
  *(*(directions + 1) + 0) = 1;  *(*(directions + 1) + 1) = 0;  // Down
  *(*(directions + 2) + 0) = 0;  *(*(directions + 2) + 1) = -1; // Left
  *(*(directions + 3) + 0) = 0;  *(*(directions + 3) + 1) = 1;  // Right
  *(*(directions + 4) + 0) = -1; *(*(directions + 4) + 1) = -1; // Up left
  *(*(directions + 5) + 0) = -1; *(*(directions + 5) + 1) = 1;  // Up right
  *(*(directions + 6) + 0) = 1;  *(*(directions + 6) + 1) = -1; // Down left
  *(*(directions + 7) + 0) = 1;  *(*(directions + 7) + 1) = 1;  // Down right

  // cases cant use ternory operator due to no if else. return 1 condition has been met and program continunes, return 0 condition has not been met and does not continue. 
  if (currentchar == strlen(word)) return 1; // if the current letter is the last letter then return one
  if (row < 0 || row >= bSize || col < 0 || col >= bSize) return 0; // checks the boundary of the 2d array, using or operator
  if (ignoreCapital(*(*(arr + row) + col)) != ignoreCapital(*(word + currentchar))) return 0; // if call function ignore capitol location of letter does not equal to location of word plus current char then return 0 
  if (*(counts + ignoreCapital(*(word + currentchar))) <= 0) return 0; // if counts[ignore(word[currentchar])] <= 0 then condition not met do not continue so if counts <= 0 then return 0. so it doesnt have to check for the same letter again in the word


  char *buffer = (char*) malloc(bSize * sizeof(char)); //char buffer array set to bsize used as a temp storage to keep multiple integers in the visited array
  sprintf(buffer, "%d", currentchar + 1); // converts currentchar to a string and puts it in buffer, sprintf means string print formatted, combines char and int data types

  // used to add the contents of buffer array into the visited array
  if (strlen(*(*(visited + row) + col)) > 0) {
      strcat(*(*(visited + row) + col), buffer);
  } else {
      strcpy(*(*(visited + row) + col), buffer);
  }// if the length of the string visited at location of row and col is > 0 then add buffer contents into visited array, else copy buffer contents into visited array


  *(counts + ignoreCapital(*(word + currentchar))) -= 1; // decrease counts size
  for (int i = 0; i < 8; ++i) {
    if (searchFrom(visited, arr, word, row + *(*(directions + i) + 0) , col + *(*(directions + i) + 1)
, currentchar + 1, counts)) {// if call function search from, give it visited, arr, word, row + directions[i][0], currentchar (current letter looking for) + 1 so that first letter is 1 instead of zero, counts then return 1
      return 1;
    }
  }

  // backtrace, undo additions to visited if there is nothing related to word found, visited is subtracted by buffer removing any additions to visited
  *(*(*(visited + row) + col) + strlen(*(*(visited + row) + col)) - strlen(buffer)) = '\0';
  *(counts + ignoreCapital(*(word + currentchar))) += 1;// increase count that is compated to the current letter in word, so looks at current character in word then calls ignores capitol function, and that is going to the count of that letter in the word.  

  return 0;
}

// allocates a new array visited to keep track of cells visited, 
void searchPuzzle(char** arr, char* word) {
  // counts how many times a letter appears in word so that it can correctly find how many times a letter shows up in the word array
  int *counts = (int *)malloc(256 * sizeof(int));
  if (counts == NULL) {
      exit(1);
  }
  memset(counts, 0, 256 * sizeof(int));

  for (int i = 0; i < strlen(word); ++i) {
    *(counts + ignoreCapital(*(word + i))) += 1;// ignores uppercase to match and count that, word is an array and each letter is stored there, as the i increases the function ignorecapital is ran to ignore the capital and it gives the amount of times a letter shows up in the word into the counts array that is populated by zeros. and the program runs the length of the word. 
  }

  char ***visited = malloc(bSize * sizeof(char**)); // points to an array of pointers where each pointer is an array of char, so that there can be multiple numbers in the final print array. basically having multiple 2d arrays of the size of bSize but bSized amount. so 3 3x3 arrays in an array 
  for (int i = 0; i < bSize; ++i) {
    *(visited + i) = malloc(bSize * sizeof(char*)); // allocates bSized Cell row
    for (int j = 0; j < bSize; ++j) {
      *(*(visited + i) + j) = malloc(bSize * sizeof(char)); // allocates memory for each cell, column
      strcpy(*(*(visited + i) + j) , "");// sets the 2d arrays in ***visited to be a string character currently empty 
    }
  }

  
  for (int i = 0; i < bSize; ++i) {
    for (int j = 0; j < bSize; ++j) {
      if (ignoreCapital(*(*(arr + i) + j)) == ignoreCapital(*(word)) && *(counts + ignoreCapital(*word)) > 0) {// if calls function using arr stuff stored at location i , j is equal to call function using first letter of word(calls function to ignore the capital letter) && and  counts calls function using first letter of word is greater than 0 then
        if (searchFrom(visited, arr, word, i, j, 0, counts)) { // if calls function searchfrom and gives the function, visited, arr, word, i, j , 0, and counts then
          printf("Word found!\n");
          printf("Printing the search path: \n"); 
          for (int m = 0; m < bSize; ++m) { // traverse rows of the file array
            for (int n = 0; n < bSize; ++n) { // traverse columns of the file array
              if (strlen(*(*(visited + m) + n)) == 0) {
                printf("0\t"); // print out zeros for formatting to look similar to the file array
              } else {
                printf("%s\t", *(*(visited + m) + n)); // prints out the stuff stored in the 2d array of visited. 
              }
            }
            printf("\n");
          }

          return;
        }
      }
    }
  }
  printf("Word not found!\n");
}


// gcc -w wordsearch.c -o 



