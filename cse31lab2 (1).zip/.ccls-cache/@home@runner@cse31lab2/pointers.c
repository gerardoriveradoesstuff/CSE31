#include <stdio.h>

int main() {
  int x = 2, y = 3, *px = x, *py = y;
  int arr[10];
  arr[0] = x;
  printf("Value of x: %d\n", x);
  printf("Value of y: %d\n", y);
  printf("Value of Arr[0]: %d\n", arr[0]);
  printf("Address of X: %d\n", &px);
  printf("Address of X: %d\n", &py);
  printf("Address of X: %d\n", px);
  printf("Address of X: %d\n", py);
  for(int i = 0; i < 10; i++) {
    printf("%d\n", *(&arr + i));
  }
  printf("Address of Arr: %d\n", &arr);
  return 0;
}
