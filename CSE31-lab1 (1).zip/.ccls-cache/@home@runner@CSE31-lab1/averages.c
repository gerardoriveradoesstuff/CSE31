#include <stdio.h>
#include <stdlib.h>

int main() {
  int *dynamicArray = NULL; 
  int number = 0, arraysize = 0, sum = 0;
  char *numname = "th";

  while (1) {
    if (number == arraysize) {
      arraysize = (arraysize == 0) ? 1 : arraysize * 2;
      dynamicArray = realloc(dynamicArray, arraysize * sizeof(int)); // resizes the array when theres new stuff to add, also makes it size 1 if its size zero
      if (dynamicArray == NULL) {
        exit(1); // error check
      }
    }
    
    if (number == 0) numname = "st";
    else if (number == 1) numname = "nd";
    else if (number == 2) numname = "rd";// changes char to different characters to name the number
    else if (number > 2) numname = "th";
    printf("Enter the %d%s value: ", number + 1, numname); 
    scanf("%d", &dynamicArray[number]);// gets user input and stores it into dynamic array without changing the number value
    if (dynamicArray[number] == 0) {
      if (number == 0) {
        printf("There is no average to compute \n");// error check
      }
      break;
    }
    sum = sum + dynamicArray[number]; // counts the number of things in the array 
    number++; 
  }

  if (number > 0) { //makes sure there is a valid number to calculate
    float average = (float) sum / number; // calculates the average 
    printf("Average of input values whose digits sum up to an %s number: %.2f \n", 
    average, (sum % 2 == 0) ? "even" : "odd");
  } 
  free(dynamicArray);

  return 0;
}

// gcc -w averages.c -o app
