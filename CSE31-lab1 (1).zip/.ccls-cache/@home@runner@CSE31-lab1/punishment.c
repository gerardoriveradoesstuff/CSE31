#include <stdio.h>

int main() {
  int lines,typoamount;
  char typo[] = "Cading wiht is C avesone:(", regularline[] = "Coding with is C awesome!";

  printf("Enter the repetition count for the punishment phrase: "); 
  scanf("%d", &lines);
  while(lines <=0) {
    printf("You entered an invalid input for repetition count! PLease re-enter:");
    scanf("%d", &lines);
  }
  
  printf("Enter the line where you want to insert the typo: ");
  scanf("%d", &typoamount);
  while(typoamount <= 0 || typoamount > lines) {
    printf("You entered an invalid input for repetition count! PLease re-enter:");
    scanf("%d", &typoamount);
  }
  
  for (int i = 1; i <= lines; i++) {
    if (i == typoamount) {
      printf("%s\n", typo);
    } else {
      printf("%s\n", regularline);
    }
  }

  
  return 0;
}





